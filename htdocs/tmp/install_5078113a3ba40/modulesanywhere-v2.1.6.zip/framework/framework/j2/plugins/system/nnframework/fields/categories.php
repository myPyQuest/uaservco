<?php
defined('_JEXEC') or die;
// not used