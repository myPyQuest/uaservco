<?php
/**
 * @package     EasyTable Pro
 * @Copyright   Copyright (C) 2010- Craig Phillips Pty Ltd.
 * @license     GNU/GPL http://www.gnu.org/copyleft/gpl.html
 * @author      Craig Phillips {@link http://www.seepeoplesoftware.com}
 */
defined('_JEXEC') or die ('Restricted Access');
jimport( 'joomla.plugin.plugin' );

class plgSearchEasyTables extends JPlugin
{
	/**
	 *	Search for matches in a table and return an array of record id's.
	 */
	function getMatchingRecordsIn (&$thisTable, &$searchText, $joiner, $ordering)
	{
		//-- OK, to make the plugin aware of our translations we need to explicitly load
		//   the components language file.
		$language = JFactory::getLanguage();
		$language->load('plg_search_easytables');

		// Use the right table name
		if( $thisTable['datatablename'] == '')
		{
			$tName = '#__easytables_table_data_'.$thisTable['id'];
		}
		else
		{
			$tName = $thisTable['datatablename'];
		}

		// Search the tables data for matching records
		$searchQuery = 'SELECT `id` FROM '.$tName.' WHERE ';
		
		// Get the fields in this table that we're allowed to search
		$searchFields = $this->getSearchFieldsIn($thisTable['id']);

		// Build an array of where segments using fields and the searchtext array
		$whereSegments = array();

		// Where segments will vary based on their joining mechanism...
		foreach ( $searchFields as $searchField )
		{
			$tmpFieldLike = '(`'.$searchField['fieldalias'].'` LIKE \'';
			$whereSegmentForThisField = '';
			$numberOfSearchWords = count($searchText);
			$currentWord = 1;
			foreach ( $searchText as $searchWord )
			{
				$whereSegmentForThisField .= $tmpFieldLike.$searchWord."')";
				if(($currentWord == 1) && ($joiner == 'AND'))
				{
					$whereSegmentForThisField = '( '.$whereSegmentForThisField;
				}
				if($currentWord++ < $numberOfSearchWords)
				{
					if($joiner == 'AND')
					{
						$whereSegmentForThisField .= ' AND ';
					}
					else
					{
						$whereSegmentForThisField .= ' OR ';
					}
				}
				if(($currentWord == ($numberOfSearchWords+1)) && ($joiner == "AND"))
				{
					$whereSegmentForThisField .= ' )';
				}
			}

			$whereSegments[] = $whereSegmentForThisField;
		}

		// Make sure we have a valid join string.
		if(($joiner == '') || ($joiner =='AND'))
		{
			$joiner = 'OR';
		}

		// Collapse the array to create the where'
		$wherePhrase = implode ( ' '.$joiner.' ', $whereSegments );

		// Now we assemble the query to retreive the records that match
		$recordSearchQuery = 'SELECT * FROM `'.$tName.'` WHERE '.$wherePhrase;
		$db =& JFactory::getDBO();
		$db->setQuery($recordSearchQuery);
		$records = $db->loadAssocList();
		
		if(count($records))
		{
			if(count($records) > 1)
			{
				$resultText = JText::_('FOUND_THESE_RECORDS_THAT_MATCH_').' <BR />';
			}
			else 
			{
				$resultText = JText::_('FOUND_A_RECORD_THAT_MATCHES_').' <BR />';
			}

			$href = 'index.php?option=com_easytablepro&view=easytable&id='.$thisTable['id'].':'.$thisTable['easytablealias'];
			$hrefForRec = 'index.php?option=com_easytablepro&view=easytablerecord&id='.$thisTable['id'].':'.$thisTable['easytablealias'].'&rid=';
			$recIDs = '';

			foreach ( $records as $rec )
			{
				$resultText .= '<a href="'.JRoute::_($hrefForRec.$rec['id']).'"> #'.$rec['id'].'</a>, ';
				$recIDs .= '&srid[]='.$rec['id'];
			}

			$href .= $recIDs;
			$resultArray = array('title' => $thisTable['easytablename'],
								 'text' => $resultText,
								 'created' => $thisTable['modified_'],
								 'section' => 'EasyTables',
								 'href' => JRoute::_($href),
								 'browsernav' => '2');
		}
		else 
		{
			$resultArray = array();
		}
		
		return $resultArray;
	}

	/**
	 *	Return the search enabled fields of a table.
	 */
	function getSearchFieldsIn ($tableID)
	{
		$db =& JFactory::getDBO();
		$query = "SELECT `fieldalias` FROM #__easytables_table_meta WHERE `easytable_id` = $tableID AND (`params` LIKE '%search_field=1%')";
		$db->setQuery($query);
		$fields = $db->loadAssocList();
		return $fields;
	}

	/**
	 * Gets the tables
	 * @return data
	 */
	function getSearchablePublishedEasyTables($theSortSQL='')
	{
		// Get the components global search setting
		$params = &JComponentHelper::getParams( 'com_easytablepro' );
		$globalSearchSetting = $params->get('searchable_by_joomla');
		// setup the params SQL component
		if($globalSearchSetting == 1)
		{
			$paramsSQL = "((`params` LIKE '%searchable_by_joomla=1%') OR (`params` NOT LIKE '%searchable_by_joomla=0%'))";
		}
		else
		{
			$paramsSQL = "(`params` LIKE '%searchable_by_joomla=1%')";
		}

		// Get the searchable tables
		$rows = '';
		$db =& JFactory::getDBO();
		$query = "SELECT `id`, `datatablename`, `easytablename`, `easytablealias`, `modified_` FROM #__easytables WHERE `published` = '1' AND ".$paramsSQL;

		if(strlen($theSortSQL))
		{
			$query .= ' ORDERED BY '.$theSortSQL;
		}

		$db->setQuery($query);

		$rows = $db->loadAssocList();

		return $rows;

	}

	function onSearchAreas($value='')
	{
		static $areas = array('easytables' => 'EasyTable Records');
		return $areas;
	}
	
	function onSearch($text, $phrase = '', $ordering = '', $areas = null)
	{
		$resultArray = array();
		
		// Is there search text?
		if (!$text)
		{
			// No search text lets bail.
			return $resultArray;
		}
	
		// Ok, we have search text but does the user want to look in a specific area?
		if (is_array( $areas ))
		{
			// Are EasyTable records one of the areas the user wants to look?
			if (!array_intersect( $areas, array_keys( $this->onSearchAreas() ) ))
			{
				// Ok not looking in EasyTable records for the user, we can bail.
				return $resultArray;
			}
		}

		// It looks good lets get the current Database Object from the Joomla framework
		$db =& JFactory::getDBO();

		// Build up the text to match against
		$searchText = array();
		$joiner = '';

		if($phrase == 'exact')
		{
			$searchText[] = "%$text%";
		}
		else
		{
			$searchWords = explode ( ' ', $text);
			foreach ( $searchWords as $aWord )
			{
			    $searchText[] = '%'.$aWord.'%';
			}

			// Setup our joining statement for search words
			if($phrase == 'all')
			{
				$joiner = "AND";
			}
			else
			{
				$joiner = "OR";
			}
		}

		// Get the tables that are published and searchable and check them for matches...
		$searchableTables =& $this->getSearchablePublishedEasyTables();

		// Loop through the tables and store hits
		foreach ( $searchableTables as $thisTable )
		{
		    $ahit = $this->getMatchingRecordsIn ($thisTable, $searchText, $joiner, $ordering);
		    if(count($ahit))
		    {
		    	$resultArray[] = (object)$ahit;
		    }
		}

		return $resultArray;
	}
}
