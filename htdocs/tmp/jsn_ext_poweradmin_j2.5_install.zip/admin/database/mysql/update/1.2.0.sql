
RENAME TABLE `#__poweradmin_history` TO `#__jsn_poweradmin_history` ;