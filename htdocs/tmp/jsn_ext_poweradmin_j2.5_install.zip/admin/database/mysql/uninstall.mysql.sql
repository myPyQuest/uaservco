DROP TABLE IF EXISTS `#__poweradmin_history`;
DROP TABLE IF EXISTS `#__jsn_poweradmin_history`;
DROP TABLE IF EXISTS `#__jsn_poweradmin_config`;